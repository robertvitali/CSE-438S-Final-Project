//
//  Profile.swift
//  TasksApp_Final_Project
//
//  Created by Xiangmin Zhang on 12/3/18.
//  Copyright © 2018 Robert Vitali. All rights reserved.
//

import Foundation

struct Profile{
    static var displayInF:Bool?
    static var darkMode:Bool?
}
