//
//  Colors.swift
//  TasksApp_Final_Project
//
//  Created by Spencer Blackwood on 12/2/18.
//  Copyright © 2018 Robert Vitali. All rights reserved.
//

import Foundation
import UIKit

struct Colors {
    static let headerBackground = UIColor(displayP3Red: 110.0/255, green: 193.0/255, blue: 248.0/255, alpha: 0.8)
}
